helm upgrade weblogic-operator ../weblogic-operator -n wko-operator --values ../weblogic-operator/override-values.yaml --set "domainNamespaceSelectionStrategy=List" --set "domainNamespaceLabelSelector=operator=enabled" --set "domainNamespaces={brm15-pindb}"
sleep 30

helm get values weblogic-operator -n wko-operator
