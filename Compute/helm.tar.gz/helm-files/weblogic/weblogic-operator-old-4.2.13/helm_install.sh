helm install weblogic-operator ../weblogic-operator -n wko-operator --values ../weblogic-operator/override-values.yaml
sleep 45

helm get values weblogic-operator -n wko-operator
