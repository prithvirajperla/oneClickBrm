helm install weblogic-operator ../weblogic-operator -n weblogic-operator --values ../weblogic-operator/override-values.yaml
sleep 45

helm get values weblogic-operator -n weblogic-operator
