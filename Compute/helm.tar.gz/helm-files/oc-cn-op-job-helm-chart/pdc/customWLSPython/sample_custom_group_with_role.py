def grantPDCRoleToWlsGroup(pdcRole, wlsGroup):
	try:
            print('\n[INFO] Grant PDC Role: '+pdcRole+' to WebLogic Group: '+wlsGroup)
	    grantAppRole(appStripe="PricingDesignCenter", appRoleName=pdcRole,principalClass="weblogic.security.principal.WLSGroupImpl",principalName=wlsGroup)
            print('\n[INFO] Grant Succeeded')
        except Exception, e:
            msg = str(e)
            if ("is already a member of application role" in msg):
                print "\n[INFO] Custom group: "+wlsGroup+" is already member of application role: "+pdcRole+".\n"
            else:
                print('\n[INFO] Failed to grant role '+ pdcRole+' to '+wlsGroup+'.')
                print('\n[INFO] Check if role not already granted.')
            
def createCustomGroup(wlsGroup):
    if (cmo.groupExists(wlsGroup) == 0):
        cmo.createGroup(wlsGroup,wlsGroup)

print '\n[INFO] Start WLST Grant PDC Roles to Sample Groups with No Space ...\n'
host=os.getenv('HOSTNAME',"localhost")
connect("weblogic", "Cgbu1234#", "t3://"+host+":8001")

serverConfig()
cd('/SecurityConfiguration/pdc-domain/Realms/myrealm/AuthenticationProviders/DefaultAuthenticator')
print '\n[INFO] List of PDC Roles: \n'
listAppRoles(appStripe="PricingDesignCenter")
print '\n[INFO] End of PDC Roles: \n'
customGroupName="SamplePricingDesignAdminGrp"
createCustomGroup(customGroupName)
grantPDCRoleToWlsGroup("PricingDesignAdminRole",customGroupName)
print '\n[INFO] List of Group Members of PDC Role: PricingDesignAdminRole \n'
listAppRoleMembers(appStripe="PricingDesignCenter", appRoleName="PricingDesignAdminRole")

customGroupName="SamplePricingReviewerGrp"
createCustomGroup(customGroupName)
grantPDCRoleToWlsGroup("PricingReviewerRole",customGroupName)
print '\n[INFO] List of Group Members of PDC Role: PricingReviewerRole \n'
listAppRoleMembers(appStripe="PricingDesignCenter", appRoleName="PricingReviewerRole")

customGroupName="SamplePricingAnalystGrp"
createCustomGroup(customGroupName)
grantPDCRoleToWlsGroup("PricingAnalystRole",customGroupName)
print '\n[INFO] List of Group Members of PDC Role: PricingAnalystRole \n'
listAppRoleMembers(appStripe="PricingDesignCenter", appRoleName="PricingAnalystRole")

disconnect()
print '\n[INFO] Completed - WLST Grant PDC Roles to Sample Groups with No Space ...\n'


