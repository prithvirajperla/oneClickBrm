print '\n[INFO] Start - Custom Weblogic WLST - Admin Log Rotation  ...\n'
host=os.getenv('HOSTNAME',"localhost")
connect("weblogic", "STdevlop_123#", "t3://" + host + ":8001")
edit()
startEdit()
cd('/Servers/adminserver')
cmo.setWeblogicPluginEnabled(true)
save()
activate()
disconnect()
print '\n[INFO] Completed - Custom Weblogic WLST - Admin Log Rotation  ...\n'
