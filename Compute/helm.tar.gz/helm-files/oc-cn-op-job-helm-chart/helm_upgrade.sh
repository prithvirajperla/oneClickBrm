#!/bin/bash
 
if [ $# -eq 0 ]
  then
    echo "Namespace need to be provided with this shell script"
    echo "Example: ./helm_upgrade.sh namespace"
    exit 1
fi

NAMESPACE="$1"
RELEASE_NAME="op-job"
BRMENV=$(echo "$NAMESPACE" | cut -d'-' -f2)

echo "You are trying to upgrade oc-cn-op-job-helm-chart on $NAMESPACE"
 
  
helm upgrade $RELEASE_NAME ../oc-cn-op-job-helm-chart --namespace $NAMESPACE --values ../oc-cn-op-job-helm-chart/override-values.yaml --values ../oc-cn-op-job-helm-chart/$BRMENV-op-job-override-values.yaml 
