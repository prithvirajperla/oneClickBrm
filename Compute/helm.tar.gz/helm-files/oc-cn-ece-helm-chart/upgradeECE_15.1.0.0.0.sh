#!/bin/bash

#
# Copyright (c) 2023, Oracle and/or its affiliates.
#
#    This software is the confidential and proprietary information of
#    Oracle Corporation.  You shall not disclose such confidential and pro-
#    proprietary information and shall use it only in accordance with the
#    terms of the license agreement you entered into with Oracle Corporation.
#
#    Oracle makes no representations or warranties about the suit-
#    ability of the software, either express or implied, including but not
#    limited to the implied warranties of merchantability, fitness for a
#    particular purpose, or non-infringement.  Oracle Corporation. shall not be
#    liable for any damages suffered by licensee as a result of using,
#    modifying or distributing this software or its derivatives.
#
#    Oracle Corporation is located at http://www.oracle.com.
#
#    This notice may not be removed or altered.
#    and open the template in the editor.
#

STAGING_DIR=`pwd`
OVERRIDE_VALUES=""
NAMESPACE=""
READY_ECS=0
DESIRED_ECS=0
READY_ECS1=0
DESIRED_ECS1=0
RELEASE_NAME=""
SKIP_PRE_UPGRADE_SETUP=""

declare -a apps=()
declare -a gateways=()
declare -a agents=()

printLog() {
  if [ "$1" == "log_info" ]; then
      echo "------------------------------------------------------------" | tee -a $LOG_FILE
      echo "    STAGE $2: $3   $4 "                                       | tee -a $LOG_FILE
      echo "------------------------------------------------------------" | tee -a $LOG_FILE
      echo "                                                            " | tee -a $LOG_FILE
      echo "                                                            " | tee -a $LOG_FILE
  fi
}

deleteJobs() {
  printLog "$1" "2" "deleteJobs" "STARTED"

  JOBS=`kubectl -n $NAMESPACE get job |egrep -i "configloader|customerloader" |awk -F" " '{print $1}'`
  for job in $JOBS; do
    echo "Deleting job : $job " | tee -a $LOG_FILE
    kubectl -n $NAMESPACE delete job $job
  done

  printLog "$1" "2" "deleteJobs" "COMPLETED"
}

deleteEcs1() {
  printLog "$1" "9" "deleteEcs1" "STARTED"
  sleep 10
  kubectl -n $NAMESPACE delete sts ecs1 > /dev/null 2>&1
  printLog "$1" "9" "deleteEcs1" "COMPLETED"
}

getCurrentEcsPodCount() {
  printLog "$1" "1" "getCurrentEcsPodCount" "STARTED"

  ECS_STS=`kubectl -n $NAMESPACE get sts |grep -w "ecs" |awk -F" " '{print $1}'`
  if [ ! -z $ECS_STS ]; then
      READY_ECS=`kubectl -n $NAMESPACE get sts ecs | grep -i ecs | awk -F" " '{print $2}' |awk -F"/" '{print $1}'`
      DESIRED_ECS=`kubectl -n $NAMESPACE get sts ecs | grep -i ecs | awk -F" " '{print $2}' |awk -F"/" '{print $2}'`

      echo "Before upgrade, current ready ecs: $READY_ECS and desired ecs: $DESIRED_ECS " | tee -a $LOG_FILE
      if [ "$READY_ECS" != "$DESIRED_ECS" ]; then
        echo "ecs pods are not ready. try again later..." | tee -a $LOG_FILE
        exit -1
      fi
  fi

  ECS1_STS=`kubectl -n $NAMESPACE get sts |grep -w "ecs1" |awk -F" " '{print $1}'`
  if [ ! -z $ECS1_STS ]; then
       READY_ECS1=`kubectl -n $NAMESPACE get sts ecs1 | grep -i ecs1 | awk -F" " '{print $2}' |awk -F"/" '{print $1}'`
       DESIRED_ECS1=`kubectl -n $NAMESPACE get sts ecs1 | grep -i ecs1 | awk -F" " '{print $2}' |awk -F"/" '{print $2}'`

       echo "Before upgrade, current ready ecs1: $READY_ECS1 and desired ecs1: $DESIRED_ECS1 " | tee -a $LOG_FILE
       if [ "$READY_ECS1" != "$DESIRED_ECS1" ]; then
          echo "ecs1 pods are not ready. try again later..." | tee -a $LOG_FILE
          exit -1
       fi
  fi

  printLog "$1" "1" "getCurrentEcsPodCount" "COMPLETED"
}

getECEapps() {
  for app in `kubectl -n $NAMESPACE get sts |egrep -i "ecs|customerupdater|emgateway|diametergateway|httpgateway|cdrformatter" | awk -F" " '{print $1}'`;
  do
    apps+=( $app )
  done

  for app in `kubectl -n $NAMESPACE get deploy |egrep -i "pricingupdater|brmgateway|cdrgateway" | awk -F" " '{print $1}'`;
  do
    apps+=( $app )
  done

  for gateway in `kubectl -n $NAMESPACE get sts |egrep -i "diametergateway|httpgateway|radiusgateway" | awk -F" " '{print $1}'`;
  do
    gateways+=( $gateway )
  done

  for agent in `kubectl -n $NAMESPACE get deploy |egrep -i "monitoringagent" | awk -F" " '{print $1}'`;
  do
    agents+=( $agent )
  done
}

waitForPodToTerminate() {
  pod=$1
  while true
  do
      kubectl -n $NAMESPACE get po | grep -i $pod | grep -i terminating > /dev/null 2>&1
      if [ $? -eq 0 ]; then
         echo "Sleeping for 10s..."
         sleep 10
      else
         break
      fi
  done
}

restartGatewaysAndAgent() {

  printLog "$1" "11" "restartGatewaysAndAgent" "STARTED"

  for pod in ${gateways[@]};
  do
     echo "Scaling down $pod to 0 replica"
     kubectl -n $NAMESPACE scale sts $pod --replicas=0
     waitForPodToTerminate $pod
  done

  for pod in ${agents[@]};
  do
     echo "Scaling down $pod to 0 replica"
     kubectl -n $NAMESPACE scale deploy $pod --replicas=0
     waitForPodToTerminate $pod
  done

  for pod in ${gateways[@]};
  do
     echo "Scaling up $pod to 1 replica. Scale $pod to desired replicas after upgrade."
     kubectl -n $NAMESPACE scale sts $pod --replicas=1
  done

  for pod in ${agents[@]};
  do
     echo "Scaling up $pod to 1 replica."
     kubectl -n $NAMESPACE scale deploy $pod --replicas=1
  done

  printLog "$1" "11" "restartGatewaysAndAgent" "COMPLETED"
}

waitforPodstobeReady() {
  arg=$1
  while true
  do
    if [[ "$arg" == pricingupdater* || "$arg" == brmgateway* || "$arg" == cdrgateway* ]]; then
        READY_PODS=`kubectl -n $NAMESPACE get deploy $arg |grep -i $arg | awk -F" " '{print $2}' |awk -F"/" '{print $1}'`
        DESIRED_PODS=`kubectl -n $NAMESPACE get deploy $arg | grep -i $arg | awk -F" " '{print $2}' |awk -F"/" '{print $2}'`
    else
        READY_PODS=`kubectl -n $NAMESPACE get sts $arg 2>/dev/null |grep -i $arg | awk -F" " '{print $2}' |awk -F"/" '{print $1}'`
        DESIRED_PODS=`kubectl -n $NAMESPACE get sts $arg 2>/dev/null | grep -i $arg | awk -F" " '{print $2}' |awk -F"/" '{print $2}'`
    fi
    if [ -z $READY_PODS ] || [ -z $DESIRED_PODS ]; then
       echo "No replica found for $arg"
       sleep 5
       break;
    fi
    if [ "$READY_PODS" != "$DESIRED_PODS" ]; then
       echo "all desired $arg pods are not yet ready. sleeping for 30s..." | tee -a $LOG_FILE
       sleep 30
    else
       echo "all desired $arg pods are ready now." | tee -a $LOG_FILE
       sleep 5
       break;
    fi
  done

}

scaleDownEcs1() {
  printLog "$1" "5" "scaleDownEcs1" "STARTED"
  ecs1_replica=$DESIRED_ECS1
  while [ $ecs1_replica -gt 0 ]; do
    ecs1_replica=$((ecs1_replica - 1))
    echo "Scaling down ecs1 replica to $ecs1_replica" | tee -a $LOG_FILE
    kubectl -n $NAMESPACE scale sts ecs1 --replicas=$ecs1_replica
    echo "Scaled down ecs1 replica to $ecs1_replica" | tee -a $LOG_FILE
    echo "Sleeping for 60s."
    sleep 60
  done
  printLog "$1" "5" "scaleDownEcs1" "COMPLETED"
}

spawnEcs() {
  printLog "$1" "3" "spawnEcs" "STARTED"
  CURRENT_ECS=$DESIRED_ECS
  DESIRED_ECS=$((DESIRED_ECS + DESIRED_ECS1))
  echo "Minimum desired ecs replicas must be $DESIRED_ECS . checking available ecs replica... " | tee -a $LOG_FILE
  if [ $CURRENT_ECS -lt $DESIRED_ECS ]; then
     kubectl -n $NAMESPACE scale sts ecs --replicas=$DESIRED_ECS
     echo "Spawning ecs pods..." | tee -a $LOG_FILE
  fi

  printLog "$1" "3" "spawnEcs" "COMPLETED"
}

validateAndUpgradeEce15_0() {
  printLog "$1" "7" "validateAndUpgradeEce15_0" "STARTED"

  cd $STAGING_DIR
  echo " in $STAGING_DIR directory" | tee -a $LOG_FILE
  helm lint --strict --values $OVERRIDE_VALUES .
  if [ "$?" != "0" ]; then
     echo "Helm chart(s) linted, 1 chart(s) failed" | tee -a $LOG_FILE
     exit -1
  fi

  if [ $DESIRED_ECS -lt 3 ]; then
     DESIRED_ECS=3
  fi

  helm upgrade $RELEASE_NAME --namespace $NAMESPACE --values $OVERRIDE_VALUES . --set charging.ecs.replicas=$DESIRED_ECS


  if [ "$?" != "0" ]; then
     echo "Error upgrading ECE to release 15.1.0.0.0. please check the logs..." | tee -a $LOG_FILE
     exit -1
  fi

  printLog "$1" "7" "validateAndUpgradeEce15_0" "COMPLETED"
}

usage() {
  echo
  echo "Usage: upgradeECE_15.1.0.0.0.sh [-o overrideValues_ECE.yaml] [-n namespace] [-r helm_release] [-s y]"
  echo
  echo "               -o   overrideValues_ECE.yaml"
  echo "               -n   namespace"
  echo "               -r   release"
  echo "               -s   skip preupgrade setup [ y or yes]"
  echo
  exit -1
}

while getopts "o:n:r:s:h" param
do
    case ${param} in
        o)  OVERRIDE_VALUES=${OPTARG}
            ;;
        n)  NAMESPACE=${OPTARG}
            ;;
        r)  RELEASE_NAME=${OPTARG}
            ;;
        s)  SKIP_PRE_UPGRADE_SETUP=${OPTARG}
            ;;
        *)  usage
            ;;
    esac
done

if [ ! -f $OVERRIDE_VALUES ]; then
   echo "No override values file exists..."
   exit -1
fi

if [ -z $NAMESPACE ]; then
   echo "No namespace provided..."
   exit -1
fi

if [ -z $RELEASE_NAME ]; then
   echo "No ECE 15_0 helm release name provided..."
   exit -1
fi

LOG_FILE=$STAGING_DIR/ECE_15_0_upgrade_$RELEASE_NAME_$NAMESPACE.log
if [ -f $LOG_FILE ]; then
   rm $LOG_FILE
fi

SKIP_PRE_UPGRADE_SETUP=`echo $SKIP_PRE_UPGRADE_SETUP | tr '[:upper:]' '[:lower:]'`
getECEapps

if [ "$SKIP_PRE_UPGRADE_SETUP" != "y" -a "$SKIP_PRE_UPGRADE_SETUP" != "yes" ]; then
    getCurrentEcsPodCount "log_info"
    deleteJobs "log_info"
    spawnEcs "log_info"

    printLog "log_info" "4" "waitforPodstobeReady" "STARTED"
    for pod in ${apps[@]} ; do
      waitforPodstobeReady "$pod"
    done
    printLog "log_info" "4" "waitforPodstobeReady" "COMPLETED"

    scaleDownEcs1 "log_info"

    printLog "log_info" "6" "waitforPodstobeReady" "STARTED"
    for pod in ${apps[@]} ; do
      waitforPodstobeReady "$pod"
    done
    printLog "log_info" "6" "waitforPodstobeReady" "COMPLETED"

    validateAndUpgradeEce15_0 "log_info"

    printLog "log_info" "8" "waitforPodstobeReady" "STARTED"
    for pod in ${apps[@]} ; do
        waitforPodstobeReady "$pod"
    done
    printLog "log_info" "8" "waitforPodstobeReady" "COMPLETED"

    deleteEcs1 "log_info"

    printLog "log_info" "10" "waitforPodstobeReady" "STARTED"
    for pod in ${apps[@]} ; do
      waitforPodstobeReady "$pod"
    done
    printLog "log_info" "10" "waitforPodstobeReady" "COMPLETED"

    restartGatewaysAndAgent "log_info"

    printLog "log_info" "12" "waitforPodstobeReady" "STARTED"
    for pod in ${apps[@]} ; do
        waitforPodstobeReady "$pod"
    done
    printLog "log_info" "12" "waitforPodstobeReady" "COMPLETED"
else
    getCurrentEcsPodCount
    echo "Skipping stage 2-6"
    validateAndUpgradeEce15_0
fi


if [ $? -eq 0 ]; then
   echo "Successfully invoked ECE 15.1.0.0.0 Helm Upgrade." | tee -a $LOG_FILE
fi
