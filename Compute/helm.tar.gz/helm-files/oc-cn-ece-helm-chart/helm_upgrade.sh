#!/bin/bash
 
if [ $# -eq 0 ]
  then
    echo "ECE Installed Namespace need to be provided with this shell script"
    echo "Example: ./helm_upgrade.sh namespace"
    exit 1
fi

NAMESPACE="$1"
RELEASE_NAME="brm15-ece"
ECEENV=$(echo "$NAMESPACE" | cut -d'-' -f2)

echo "You are trying to upgrade oc-cn-ece-helm-chart on $NAMESPACE"
 
  
helm upgrade $RELEASE_NAME ../oc-cn-ece-helm-chart --namespace $NAMESPACE --values ../oc-cn-ece-helm-chart/override-values.yaml --values ../oc-cn-ece-helm-chart/$ECEENV-ece-override-values.yaml 
