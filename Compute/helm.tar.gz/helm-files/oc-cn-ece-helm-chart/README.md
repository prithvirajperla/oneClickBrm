
# CN ECE release 15.0

## Upgrade CN ECE release 15.0
use below command to upgrade CN ECE release 15.0 from CN ECE PS8 patchset

```shell
cd <path_to_ece_15.0_helmcharts>
upgradeECE_15.0.0.0.0.sh [-o overrideValues_ECE.yaml] [-n namespace] [-r helm_release]
```

Note:
1. configloader job has been replaced with single replica configloader
   deployment.
2. Make sure to update override file with newly introduced attributes by comparing base ECE release values.yaml
   file.
3. Make sure to use only 15.0.0.0.0 helm charts templates before installing/upgrading to this CN ECE 15.0.0.0.0
   release.

## Jconsole connection to management enabled ecs pod
From CN ECE release onward, ecs1 deployment has been deprecated.
user have option to make 1 or few replicas of ecs deployment to be management enabled using field
```managementEnabledReplicas``` in override file. Value of ```managementEnabledReplicas``` attribute
must be at least 1 and less than ```replicas``` attribute of ecs.

use below command to label ecs pod for jconsole connection
```shell
kubectl -n namespace label po ecs-0 ece-jmx=ece-jmx-external
```

## Reload AppConfiguration using kubernetes job
1. Update values override file with modified attribute of appConfiguration Mbean.
   i.e.
   ```
   charging:
      server:
         degradedModeThreshold: "3"
   ``` 
2. Set ```job.chargingConfigurationReloader.reloadAppConfig.runjob``` flag in override file to "true".
   Optionally Mbean name can be provided which is supposed to be reloaded in AppConfiguration.
   i.e. "charging.server".

3. Do not change pod's spec related parameter that can trigger restart of pod on helm upgrade.
   i.e. restartCount, image, jvmGCOpts etc.

4. On helm upgrade, charging-settings.xml file in ECE config map charging-settings-namespace should
   get updated and charging-configuration-reloader job should get triggered.

5. Once job completes, execute query.sh in ecs pod and validate modified attribute in
   appConfiguration Mbean.

6. ecs pod restart may not be required once appConfiguration cache gets updated but cases like DB
   connection URL, REF, Gateways, Kafka related appConfiguration parameters are modified,
   then pod restart may be required.

## Reload Grid Log level using kubernetes job

1. charging-configuration-reloader job can also be used to reload grid log level of any component
   logger.

2. Set ```job.chargingConfigurationReloader.reloadLogging.runjob``` flag in override file to "true".
   Specify Operation name, Logger or FunctionalDomain and LogLevel in below command parameter.
   for example, command: "setGridLogLevel oracle.communication.brm.charging.appconfiguration ERROR"
   Supported Operations are setGridLogLevel, setLogLevel, setGridLogLevelForFunctionalDomain and
   setLogLevelForFunctionalDomain.

3. To persist the log level changes, update log4j2.logger.<loggerName> in override or value.yaml.

4. Invoke job for either reloading app configuration or logging at a time.

## CN ECE performance tuning and resiliency Guidelines
1. For predicable resource usage, each replica of ECE statefulsets or deployments should be bounded
   with heap, GC parameters and container memory, CPU resource request/limit.
   example:
   heap parameters can be set as ```jvmOpts: "-Xms1024m -Xmx1536m"``` in override file.
   GC parameters can be set using ```jvmGCOpts```.
   container resources can be configured as
   ```shell
    resources:
      limits:
        cpu: "500m"
        memory: "4096Mi"
      requests:
        cpu: "200m"
        memory: "1024Mi"
   ```

   if container resources are configured, make sure to allocate memory limit high enough to
   accommodate pod ```RSS``` and ```WSS``` memory.

2. Heap size must be tuned according to TPS and subscribers base.
3. For HA, Anti-affinity in emGateway, httpGateway replicas can be set similar to ecs pod.
4. In case of ECE Active-Active set up, it is desirable to have separate Load balancers for
   federation, remote site BRS requests and HttpGateway signaling traffic.
   Load balancers must be able to support bandwidth required for federation traffic.
5. Disruption to multiple ecs pods voluntarily must not be done. for example, terminating ecs pods
   manually at the same time.
6. For monitoring ECE, sample grafana dashboard jsons are provided in
   ```docker_files/samples/monitoring``` folder of ```oc-cn-ece-docker-files-release.tgz```
   
## General guidelines
1. During installation, upgrade or pod restart, ECE use kubernetes REST API to 
   - Automatically update ```charging-settings-namespace``` configmap to enable reloading of cache 
     data from persistence.
   - Get the metadata of ECE statefulsets and pods.
   - Automatically apply management label to ecs pod.
   
   In order for ECE to perform above operations required during installation, upgrade, auto-recovery 
   and pod restart, ```ece-namespace``` service account should be able to authenticate API server.
   Refer ece-clusterrole-sa.yaml file in helm chart for rules defined in RBAC Role ```ece-namespace```.