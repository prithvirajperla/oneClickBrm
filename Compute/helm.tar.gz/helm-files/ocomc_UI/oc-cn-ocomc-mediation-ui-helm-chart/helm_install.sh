helm install brm15-ocomc-ui ../oc-cn-ocomc-mediation-ui-helm-chart --namespace brm15-apps-dev3 --values ../oc-cn-ocomc-mediation-ui-helm-chart/deploy-mediation-ui.yaml 
