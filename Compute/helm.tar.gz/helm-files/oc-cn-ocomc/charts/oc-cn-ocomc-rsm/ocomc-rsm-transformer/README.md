<h1>RSM Transformers</h1>
<p>The purpose of this directory is to store custom transformers for custom market segments.</p>
<p>The directory structure should be as shown below</p>
<pre>
- ocomc-rsm-transformer
    |- CustomMarketSegment1.yaml
    |- CustomMarketSegment2.yaml
    |- CustomMarketSegment3.yaml
</pre>
<h4>Note:</h4>
<p>Just creating a directory and file here will not let RSM know about custom transformer files, please specify the custom marketSegment in the <b>values.yaml</b> file.</p>
