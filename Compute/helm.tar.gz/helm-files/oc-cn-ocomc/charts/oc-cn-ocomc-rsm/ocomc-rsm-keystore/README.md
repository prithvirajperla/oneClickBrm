<h1>RSM Keystore</h1>
<p>The purpose of this directory is to keep all the keystore and truststore files in a single directory for RSM to pick it up from.</p>
<p>For example, files such as:</p>
<ol>
<li>Admin server trust score for SSL communication with admin server</li>
<li>Keystore file for RSM webserver HTTPS support</li>
</ol>

