<h1>RSM Validator</h1>
<p>The purpose of this directory is to store custom validators for custom market segments.</p>
<p>The directory structure should be as shown below</p>
<pre>
- ocomc-rsm-validator
    |- CustomMarketSegment1
        |- Validator1.yaml
        |- Validator2.yaml
</pre>
<h4>Note:</h4>
<p>Just creating a directory and file here will not let RSM know about custom validator files, please specify the custom marketSegment in the <b>values.yaml</b> file.</p>

