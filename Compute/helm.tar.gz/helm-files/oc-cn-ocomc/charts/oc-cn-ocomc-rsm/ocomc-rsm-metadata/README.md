<h1>RSM Metadata</h1>
<p>The purpose of this directory is to store custom metadata for custom market segments.</p>
<p>The directory structure should be as shown below</p>
<pre>
- ocomc-rsm-metadata
    |- CustomMarketSegment1
        |- MetadataFile1.json
        |- MetadataFile2.json
</pre>
<h4>Note:</h4>
<p>Just creating a directory and file here will not let RSM know about custom metadata files, please specify the custom marketSegment in the <b>values.yaml</b> file.</p>
