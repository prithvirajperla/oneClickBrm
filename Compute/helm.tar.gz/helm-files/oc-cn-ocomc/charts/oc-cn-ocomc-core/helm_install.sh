#!/bin/bash
 
if [ $# -eq 0 ]
  then
    echo "OCOMC Namespace need to be provided with this shell script"
    echo "Example: ./helm_install.sh namespace"
    exit 1
fi

NAMESPACE="$1"
RELEASE_NAME="brm15-ocomc"
OCOMCENV=$(echo "$NAMESPACE" | cut -d'-' -f2)

echo "You are trying to install oc-cn-ocomc-core on $NAMESPACE"
 
  
helm install $RELEASE_NAME ../oc-cn-ocomc-core --namespace $NAMESPACE --values ../oc-cn-ocomc-core/override-values.yaml --values ../oc-cn-ocomc-core/pindb-ocomc-override-values.yaml
