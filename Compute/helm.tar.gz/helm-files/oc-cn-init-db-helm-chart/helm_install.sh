helm install brm15-initdb ../oc-cn-init-db-helm-chart -n brm15-pindb --values ../oc-cn-init-db-helm-chart/pindb-init-override-values.yaml
