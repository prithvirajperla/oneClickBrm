cd /home/charging/opt/ECE/oceceserver/bin/
./query.sh -s -c -l "update State set id=10,name=UsageProcessing"
