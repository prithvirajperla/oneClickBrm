#!/bin/bash

export PATH="/home/trainer/.local/bin:/home/trainer/bin:/usr/share/Modules/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:$PATH"

cd /home/trainer/CTS/helm-files/oc-cn-helm-chart/oc-cn-helm-chart
./domain_uninstall.sh
sleep 30
##Scale down
kubectl delete job brm-apps-jobs config-jobs ece-persistence-job ece-persistence-upgrade-job lds-config-job pdc-import-export-job pdc-seeddata-job rel-manager-job -n brm15-pindb
kubectl scale deploy pricingupdater configloader cdrgateway1 brmgateway1 -n brm15-pindb --replicas=0
kubectl scale sts -n brm15-pindb --replicas=0 --all
kubectl scale deploy rel-daemon realtime-pipe brm-sdk brm-rest-services-manager-deployment cm dm-eai dm-oracle pje batch-wireless-pipe -n brm15-pindb --replicas=0
sleep 180
for p in $(kubectl get pods -n brm15-pindb | grep Terminating | awk '{print $1}'); do kubectl -n brm15-pindb delete pod $p --grace-period=0 --force;done
for p in $(kubectl get pods -n brm15-pindb | grep Error | awk '{print $1}'); do kubectl -n brm15-pindb delete pod $p --grace-period=0 --force;done
exit
