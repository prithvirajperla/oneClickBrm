#!/bin/bash

export PATH="/home/trainer/.local/bin:/home/trainer/bin:/usr/share/Modules/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:$PATH"
cd /home/trainer/CTS/helm-files/weblogic/weblogic-operator
./regns.sh
sleep 30
cd /home/trainer/CTS/helm-files/oc-cn-helm-chart/oc-cn-helm-chart
./helm_upgrade.sh brm15-pindb
sleep 300
cd /home/trainer/CTS/helm-files/oc-cn-ece-helm-chart
./helm_upgrade.sh brm15-pindb
sleep 360
kubectl cp -n brm15-pindb /home/trainer/CTS/helm-files/jobs/ece_state.sh ecs-0:/home/charging/opt/ECE/oceceserver/bin/
kubectl exec -it ecs-0 -n brm15-pindb  -- /bin/bash /home/charging/opt/ECE/oceceserver/bin/ece_state.sh
sleep 60
cd /home/trainer/CTS/helm-files/oc-cn-ocomc/charts/oc-cn-ocomc-core
./helm_upgrade.sh brm15-pindb
sleep 60
#kubectl delete deployment webhook-deployment -n brm15-pindb
## Set NodePorts
cd /home/trainer/CTS/helm-files/oc-cn-helm-chart
./bc_np.sh
./bcws_np.sh
./boc_nap.sh
./pdcrsm_np.sh
./rsm_np.sh
cd /home/trainer/CTS/helm-files/oc-cn-helm-chart/oc-cn-helm-chart
./helm_pdc_publish.sh brm15-pindb publish
for p in $(kubectl get pods -n brm15-pindb | grep Terminating | awk '{print $1}'); do kubectl -n brm15-pindb delete pod $p --grace-period=0 --force;done
for p in $(kubectl get pods -n brm15-pindb | grep Error | awk '{print $1}'); do kubectl -n brm15-pindb delete pod $p --grace-period=0 --force;done
exit
