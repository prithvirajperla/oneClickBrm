kubectl -n brm15-pindb patch svc pdcrsm --type='json' -p '[{"op":"replace","path":"/spec/type","value":"NodePort"},{"op":"replace","path":"/spec/ports/0/nodePort","value":30456}]'
