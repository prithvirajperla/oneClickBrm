#!/bin/bash
if [ $# -eq 0 ]
  then
    echo "Namespace need to be provided with this shell script"
    echo "Example: ./helm_delete.sh namespace"
    exit 1
fi
 
NAMESPACE="$1"
RELEASE_NAME="brm15-core"
 
 
helm delete $RELEASE_NAME -n $NAMESPACE