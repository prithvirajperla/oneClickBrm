helm upgrade brm15-core ../oc-cn-helm-chart -f ../oc-cn-helm-chart/override-values.yaml -f ../oc-cn-helm-chart/pindb-brm-override-values.yaml -f ../oc-cn-helm-chart/domain-ms.yaml -n brm15-pindb
