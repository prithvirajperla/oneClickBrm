#!/bin/sh

echo "INFO: Entered common config scripts..."

##################################
echo "Loading PODL files"
cd /oms/config_jobs/podl;
./load_podl.sh dbssrm_podl.ctl
##################################

##################################
echo "Loading Config files"
cd /oms/config_jobs/sys/data/config;
./load_dbssrm_config.sh
##################################
