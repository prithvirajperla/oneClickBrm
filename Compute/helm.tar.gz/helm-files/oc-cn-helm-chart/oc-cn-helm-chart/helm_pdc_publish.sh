#!/bin/bash
 
if [ $# -eq 1 ]
  then
    echo "Namespace need to be provided with this shell script"
    echo "Example: ./helm_pdc.sh namespace publish"
    exit 1
fi

NAMESPACE="$1"
TYPE="$2"
RELEASE_NAME="brm15-core"
BRMENV=$(echo "$NAMESPACE" | cut -d'-' -f2)

echo "You are trying to upgrade oc-cn-helm-chart on $NAMESPACE and using pdc $TYPE"
kubectl delete job pdc-import-export-job -n $NAMESPACE
 
  
helm upgrade $RELEASE_NAME ../oc-cn-helm-chart --namespace $NAMESPACE --values ../oc-cn-helm-chart/override-values.yaml --values ../oc-cn-helm-chart/$BRMENV-brm-override-values.yaml --values ../oc-cn-helm-chart/$TYPE-override-values.yaml 
