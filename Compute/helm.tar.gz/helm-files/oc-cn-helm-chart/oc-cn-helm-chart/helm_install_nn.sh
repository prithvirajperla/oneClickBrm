#!/bin/bash
 
if [ $# -eq 0 ]
  then
    echo "Namespace need to be provided with this shell script"
    echo "Example: ./helm_install.sh namespace"
    exit 1
fi

NAMESPACE="$1"
RELEASE_NAME="brm15-core"
BRMENV=$(echo "$NAMESPACE" | cut -d'-' -f2)

echo "You are trying to install oc-cn-helm-chart on $NAMESPACE"
 
  
helm install $RELEASE_NAME ../oc-cn-helm-chart --namespace $NAMESPACE --values ../oc-cn-helm-chart/override-values.yaml --values ../oc-cn-helm-chart/$BRMENV-brm-override-values.yaml --values ../oc-cn-helm-chart/deployment_override-values.yaml
