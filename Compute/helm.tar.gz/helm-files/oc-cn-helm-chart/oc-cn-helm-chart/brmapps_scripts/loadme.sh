# Copyright (c) 2020, 2023, Oracle and/or its affiliates.
#!/bin/sh

exit 0
